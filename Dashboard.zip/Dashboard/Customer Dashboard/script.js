// Sample customer data (replace with actual backend data)
const customerData = {
    name: "John Doe",
    email: "john.doe@example.com",
    profilePhoto: "default-profile.jpg", // Replace with actual photo URL if available
    upcomingAppointments: [
        { service: "Oil Change", date: "2025-03-20", time: "10:00 AM" },
        { service: "Tire Change", date: "2025-03-25", time: "2:00 PM" }
    ],
    serviceHistory: [
        { service: "Computer Diagnostic", date: "2025-03-10", status: "Completed" },
        { service: "Engine Replacement", date: "2025-02-15", status: "Completed" }
    ]
};

// Update dashboard content
document.getElementById('customer-name').textContent = customerData.name;
document.getElementById('modal-customer-name').textContent = customerData.name;
document.getElementById('customer-email').textContent = customerData.email;
document.getElementById('profile-photo').src = customerData.profilePhoto;

// Populate upcoming appointments
const upcomingList = document.getElementById('upcoming-appointments');
customerData.upcomingAppointments.forEach(appointment => {
    const card = document.createElement('div');
    card.className = 'appointment-card';
    card.innerHTML = `
        <strong>${appointment.service}</strong><br>
        <span class="text-muted">Date:</span> ${appointment.date}<br>
        <span class="text-muted">Time:</span> ${appointment.time}
    `;
    upcomingList.appendChild(card);
});

// Populate service history
const historyList = document.getElementById('service-history');
customerData.serviceHistory.forEach(history => {
    const card = document.createElement('div');
    card.className = 'history-card';
    card.innerHTML = `
        <strong>${history.service}</strong><br>
        <span class="text-muted">Date:</span> ${history.date}<br>
        <span class="text-muted">Status:</span> ${history.status}
    `;
    historyList.appendChild(card);
});

// Book appointment button
document.getElementById('book-appointment').addEventListener('click', () => {
    alert('Redirecting to appointment booking page...');
    // window.location.href = '/appointment';
});

// Modal logout button
document.getElementById('modal-logout').addEventListener('click', () => {
    alert('Logging out...');
    // Add logout logic here, e.g., redirect to login page
    // window.location.href = '/login';
});